% Simscape(TM) Multibody(TM) version: 7.6

% This is a model data file derived from a Simscape Multibody Import XML file using the smimport function.
% The data in this file sets the block parameter values in an imported Simscape Multibody model.
% For more information on this file, see the smimport function help page in the Simscape Multibody documentation.
% You can modify numerical values, but avoid any other changes to this file.
% Do not add code to this file. Do not edit the physical units shown in comments.

%%%VariableName:smiData


%============= RigidTransform =============%

%Initialize the RigidTransform structure array by filling in null values.
smiData.RigidTransform(7).translation = [0.0 0.0 0.0];
smiData.RigidTransform(7).angle = 0.0;
smiData.RigidTransform(7).axis = [0.0 0.0 0.0];
smiData.RigidTransform(7).ID = "";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(1).translation = [-4.4408920985006262e-15 0 -4.4408920985006262e-15];  % mm
smiData.RigidTransform(1).angle = 2.9978416003909018e-16;  % rad
smiData.RigidTransform(1).axis = [-1 0 -0];
smiData.RigidTransform(1).ID = "B[s_tapa:1:-:s_base:1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(2).translation = [-7.1054273576010019e-15 7.1054273576010019e-15 59.999999999999993];  % mm
smiData.RigidTransform(2).angle = 1.3316710017539532e-16;  % rad
smiData.RigidTransform(2).axis = [-0.98092539753605634 -0.19438457878322024 1.2695936280357913e-17];
smiData.RigidTransform(2).ID = "F[s_tapa:1:-:s_base:1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(3).translation = [-115.00000000000017 -10.000000000000018 0];  % mm
smiData.RigidTransform(3).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(3).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(3).ID = "B[s_brazo:1:-:s_tapa:1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(4).translation = [-2.48245868306185e-13 9.9999999999999698 85.000000000000028];  % mm
smiData.RigidTransform(4).angle = 2.0943951023931962;  % rad
smiData.RigidTransform(4).axis = [-0.57735026918962595 -0.57735026918962573 -0.57735026918962551];
smiData.RigidTransform(4).ID = "F[s_brazo:1:-:s_tapa:1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(5).translation = [-15.000000000000018 5.0000000000000124 0];  % mm
smiData.RigidTransform(5).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(5).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(5).ID = "B[s_brazo:1:-:s_muneca:1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(6).translation = [-17.061620733108036 -5.0000000000000231 -1.659783421814609e-14];  % mm
smiData.RigidTransform(6).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(6).axis = [0.57735026918962584 -0.57735026918962595 0.57735026918962562];
smiData.RigidTransform(6).ID = "F[s_brazo:1:-:s_muneca:1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(7).translation = [32.929460480455518 -26.929460480455635 -31.225508642004716];  % mm
smiData.RigidTransform(7).angle = 0;  % rad
smiData.RigidTransform(7).axis = [0 0 0];
smiData.RigidTransform(7).ID = "RootGround[s_base:1]";


%============= Solid =============%
%Center of Mass (CoM) %Moments of Inertia (MoI) %Product of Inertia (PoI)

%Initialize the Solid structure array by filling in null values.
smiData.Solid(4).mass = 0.0;
smiData.Solid(4).CoM = [0.0 0.0 0.0];
smiData.Solid(4).MoI = [0.0 0.0 0.0];
smiData.Solid(4).PoI = [0.0 0.0 0.0];
smiData.Solid(4).color = [0.0 0.0 0.0];
smiData.Solid(4).opacity = 0.0;
smiData.Solid(4).ID = "";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(1).mass = 0.049459871608659355;  % kg
smiData.Solid(1).CoM = [-4.0224925690667552e-14 0.29583188425280704 18.373335900270778];  % mm
smiData.Solid(1).MoI = [37.830579188245331 38.171795859258189 43.153097578649145];  % kg*mm^2
smiData.Solid(1).PoI = [0.056517034710805845 -1.3887226694518388e-13 0];  % kg*mm^2
smiData.Solid(1).color = [0.74901960784313726 0.74901960784313726 0.74901960784313726];
smiData.Solid(1).opacity = 1;
smiData.Solid(1).ID = "s_base.ipt_{73834EB0-4CC4-7DBE-8E17-089D662FE3F8}";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(2).mass = 0.074920525517201755;  % kg
smiData.Solid(2).CoM = [-2.2997827082830315e-09 0.10483084014370139 37.928513220028648];  % mm
smiData.Solid(2).MoI = [88.772236576686652 90.373722382258023 20.715735685333524];  % kg*mm^2
smiData.Solid(2).PoI = [-0.36969859265385313 -6.1817793747928723e-09 -1.2082523488833231e-11];  % kg*mm^2
smiData.Solid(2).color = [0.74901960784313726 0.74901960784313726 0.74901960784313726];
smiData.Solid(2).opacity = 1;
smiData.Solid(2).ID = "s_tapa.ipt_{541F4429-463B-0C36-222D-329F453F36A3}";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(3).mass = 0.06273116309117556;  % kg
smiData.Solid(3).CoM = [-71.568816785869018 0 0];  % mm
smiData.Solid(3).MoI = [6.1392238763714326 79.126291199118754 77.258422721404401];  % kg*mm^2
smiData.Solid(3).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(3).color = [0.74901960784313726 0.74901960784313726 0.74901960784313726];
smiData.Solid(3).opacity = 1;
smiData.Solid(3).ID = "s_brazo.ipt_{D11D11DB-49FD-0D46-22D6-308BC05A8CA3}";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(4).mass = 0.038042228654451074;  % kg
smiData.Solid(4).CoM = [14.834683568936708 -0.10840963777591515 0];  % mm
smiData.Solid(4).MoI = [4.2651456961560443 16.206231652693461 15.702973300757957];  % kg*mm^2
smiData.Solid(4).PoI = [0 0 0.11409575498656946];  % kg*mm^2
smiData.Solid(4).color = [0.74901960784313726 0.74901960784313726 0.74901960784313726];
smiData.Solid(4).opacity = 1;
smiData.Solid(4).ID = "s_muneca.ipt_{3A665E9B-4D73-69EC-EEC9-D59D2FF745C2}";


%============= Joint =============%
%X Revolute Primitive (Rx) %Y Revolute Primitive (Ry) %Z Revolute Primitive (Rz)
%X Prismatic Primitive (Px) %Y Prismatic Primitive (Py) %Z Prismatic Primitive (Pz) %Spherical Primitive (S)
%Constant Velocity Primitive (CV) %Lead Screw Primitive (LS)
%Position Target (Pos)

%Initialize the RevoluteJoint structure array by filling in null values.
smiData.RevoluteJoint(3).Rz.Pos = 0.0;
smiData.RevoluteJoint(3).ID = "";

smiData.RevoluteJoint(1).Rz.Pos = -6.8834326368593786;  % deg
smiData.RevoluteJoint(1).ID = "[s_tapa:1:-:s_base:1]";

smiData.RevoluteJoint(2).Rz.Pos = -0.52830466610751015;  % deg
smiData.RevoluteJoint(2).ID = "[s_brazo:1:-:s_tapa:1]";

smiData.RevoluteJoint(3).Rz.Pos = 179.99999999999997;  % deg
smiData.RevoluteJoint(3).ID = "[s_brazo:1:-:s_muneca:1]";

