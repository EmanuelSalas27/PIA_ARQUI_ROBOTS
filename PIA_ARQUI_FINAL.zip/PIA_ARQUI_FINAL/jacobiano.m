     q1 = sym("q1");
    q2 = sym("q2");
    q3 = sym("q3");
    l1 = sym("l1");
    l2 = sym("l2");
    l3 = sym("l3");
    l4 = sym("l4");



    T01z = [cos(q1) -sin(q1) 0 0;
           sin(q1)  cos(q1) 0 0;
           0          0     1 l1;
           0          0     0  1;];

    T01x = [1 0 0 -l2;
           0 1 0  0;
           0 0 1  0;
           0 0 0  1];

    T12z = [1 0 0 0;
       0 1 0  0;
       0 0 1  0;
       0 0 0  1];

    T12x = [1   0      0      0;
           0 sin(q2)  cos(q2) 0;
           0 -cos(q2)  sin(q2) 0;
           0    0      0       1;];

    T23z = [1 0 0 0;
       0 1 0  0;
       0 0 1  l3;
       0 0 0  1];



    T23x = [1   0      0      0;
           0 cos(q3)  -sin(q3) 0;
           0 sin(q3)  cos(q3) 0;
           0    0      0       1;];
    
    T34z = [1 0 0 0;
       0 1 0  0;
       0 0 1  l4;
       0 0 0  1];

    T34x = [1 0 0 0;
   0 0 1  0;
   0 -1 0  0;
   0 0 0  1];

T04 = T01z*T01x*T12z*T12x*T23z*T23x*T34z*T34x;
simplify(T04)

z = l1 + l4*sin(q2 + q3) + l3*sin(q2);
y = l4*(cos(q1)*cos(q2)*cos(q3) - cos(q1)*sin(q2)*sin(q3)) - l2*sin(q1) + l3*cos(q1)*cos(q2);
x =  l4*(sin(q1)*sin(q2)*sin(q3) - cos(q2)*cos(q3)*sin(q1)) - l2*cos(q1) - l3*cos(q2)*sin(q1);

jb = jacobian([x,y,z],[q1,q2,q3]);
determinante = det(simplify(jb));
determinante_simplificado = simplify(determinante)

q2 = 90*pi/180
q3 = 90*pi/180
subs(determinante_simplificado)