function[x,y,z] = cinematica_directa(q1,q2,q3)

    l1 = .145;
    l2 = 0.02;
    l3 = .100;
    l4 = .065;

    y = -l2*sind(q1) + l3*cosd(q1)*cosd(q2) + l4*cosd(q1)*cosd(q2+q3);
    x = -l2*cosd(q1) -l3*sind(q1)*cosd(q2) - l4*sind(q1)*cosd(q2+q3);
    z = l1 + l3*sind(q2) + l4*sind(q2+q3);

end