function[q1,q2,q3] = cinematica_inversa(x,y,z)

    l1 = .145;
    l2 = 0.02;
    l3 = .100;
    l4 = .065;
    

    alfa = atan2d(-x,y);
    beta = asind(l2/(sqrt(x^2+y^2)));
    q1 = alfa-beta;
    d = (sqrt(x^2+y^2)) * cosd(beta);
    q3 = 180 - (acosd((l4^2 + l3^2 - (sqrt(d^2+(z-l1)^2))^2)/(2*l4*l3)));
    psi = atan2d((z-l1),d);
    alfa2= acosd((-l4^2 + l3^2 + (sqrt(d^2+(z-l1)^2))^2)/(2*l3*(sqrt(d^2+(z-l1)^2))));
    q2 = psi-alfa2;

end
