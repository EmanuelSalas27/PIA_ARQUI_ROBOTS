from sympy import *
import math
import numpy as np

q1 = Symbol("q_1")
q2 = Symbol("q_2")
q3 = Symbol("q_3")

d3 = Symbol("d_3")
a1 = Symbol("a_1")

finish = False
matrix_array = []

while not finish:
    print("Transformacion en Z")
    r = input("Magnitud rotacion: ")
    d = input("Magnitud desplazamiento: ")

    Tzb = Matrix([[cos(r), -sin(r), 0, 0],
                  [sin(r), cos(r), 0, 0],
                  [0, 0, 1, d],
                  [0, 0, 0, 1]])
    print("\n")
    pprint(Tzb, use_unicode=True)
    print("\n")
    matrix_array.append(Tzb)

    print("Transformacion en X")
    print("Usa q1,q2,q3 para los angulos y d1,d2,d3 para prismaticos")
    r = input("Magnitud rotacion: ")
    d = input("Magnitud desplazamiento: ")

    Txb = Matrix([[1, 0, 0, d],
                  [0, cos(r), -sin(r), 0],
                  [0, sin(r), cos(r), 0],
                  [0, 0, 0, 1]])

    print("\n")
    pprint(Txb, use_unicode=True)
    print("\n")
    matrix_array.append(Txb)

    print(Tzb*Txb)
    i = input("Finish? 'y' o 'n'")
    if i == 'y':
        finish = True

T = prod(matrix_array)
print("\n")
print("RESULTADO:")
print("\n")
pprint(T, use_unicode=True)

print("\n")
print("RESULTADO SIMPLIFICADO:")
print("\n")
pprint(simplify(T), use_unicode=True)
print("\n")
print(simplify(T))
latex(simplify(T))