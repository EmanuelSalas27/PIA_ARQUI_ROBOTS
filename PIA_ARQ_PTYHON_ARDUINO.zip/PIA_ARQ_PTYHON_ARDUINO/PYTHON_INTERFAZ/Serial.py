from tkinter import messagebox
import serial
import serial.tools.list_ports
import time


def get_ports():
    ports = []
    for port in serial.tools.list_ports.comports():
        ports.append(str(port).split(" ")[0])
    return ports


def send_message(message, port='/dev/ttyACM0'):
    try:
        SerialObj = serial.Serial(port) # COMxx   format on Windows ttyUSBx format on Linux

        SerialObj.baudrate = 115200  # set Baud rate to 9600

        time.sleep(3)

        SerialObj.write(bytes(message,'utf-8'))      #transmit 'A' (8bit) to micro/Arduino

        SerialObj.close()# Close the port
    except serial.PortNotOpenError as error:
        messagebox.showerror("Error",f"Port Not Selected")
        raise error

