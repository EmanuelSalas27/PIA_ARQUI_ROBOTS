import tkinter
from tkinter import messagebox

import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

from Serial import get_ports, send_message
from kinematics import forward_kinematics, inverse_kinematics

PRIMARY_COLOR = '#252323'
SECONDARY_COLOR = '#FFFFFF'

selected_port = None

AED = [0, 0, 0, 0]
pos_ant = []
pos_sig = []

window = tkinter.Tk()
window.title('KINEMATICS ROBOT')
window.geometry('700x700')
# window.resizable(False, False)
window.config(bg=PRIMARY_COLOR, padx=10, pady=10)
window.rowconfigure([0, 1, 2], weight=1)
window.columnconfigure([0, 1, 2, 3], weight=1)


def calculate_joins():
    x_value = float(x_entry.get())
    y_value = float(y_entry.get())
    z_value = float(z_entry.get())

    if x_value != '' and y_value != '' and z_value != '':
        [q1, q2, q3] = inverse_kinematics(x_value, y_value, z_value)
        q1_entry.delete(0, 'end')
        q2_entry.delete(0, 'end')
        q3_entry.delete(0, 'end')
        q1_entry.insert(0, q1)
        q2_entry.insert(0, q2)
        q3_entry.insert(0, q3)

    else:
        messagebox.showwarning('Error', 'Introduce los valores de X,Y,Z')


def calculate_positions():
    q1_value = float(q1_entry.get())
    q2_value = float(q2_entry.get())
    q3_value = float(q3_entry.get())

    if q1_value != '' and q2_value != '' and q3_value != '':

        if -90 <= q1_value <= 180 and -45 <= q2_value <= 90 and -90 <= q3_value <= 90:
            [x, y, z] = forward_kinematics(q1_value, q2_value, q3_value)
            x_entry.delete(0, 'end')
            y_entry.delete(0, 'end')
            z_entry.delete(0, 'end')
            x_entry.insert(0, x)
            y_entry.insert(0, y)
            z_entry.insert(0, z)
            plot(x, y, z)
        else:
            messagebox.showwarning('Error',
                                   'Introduce valores dentro del rango permitido:\nq1: 0 a 360\nq2: 0 a 180\nq3: 0 a '
                                   '180')

    else:
        messagebox.showwarning('Error', 'Introduce los valores de q1,q2,q3')


def set_port():
    global selected_port
    if ports_list.curselection():
        selected_port = viable_ports[ports_list.curselection()[0]]
        print(selected_port)


def search_port():
    global viable_ports
    viable_ports = get_ports()
    ports_list.delete(0, 'end')
    ports_list.insert(0, *viable_ports)


def effector_on():
    global AED
    AED[3] = 1
    off_button['state'] = 'active'
    on_button['state'] = 'disabled'


def effector_off():
    global AED
    AED[3] = 0
    on_button['state'] = 'active'
    off_button['state'] = 'disabled'


def set_joins():
    global AED
    q1 = float(q1_entry.get())
    q2 = float(q2_entry.get())
    q3 = float(q3_entry.get())
    AED[0:3] = [q1, q2, q3]


def run():
    set_joins()
    calculate_positions()
    print(AED)
    send_message(str(AED).replace('[', '<').replace(']', '>'), selected_port)



def plot(x, y, z):
    global pos_ant, pos_sig

    if pos_ant != []:
        pos_sig = [x, y, z]
    else:
        pos_ant = [x, y, z]

    print(pos_sig, pos_ant)
    global frame5
    frame5.destroy()
    frame5 = tkinter.LabelFrame(text="PLOT", bg=PRIMARY_COLOR, fg=SECONDARY_COLOR)
    figure = plt.Figure(figsize=(3, 3), dpi=100)
    ax = figure.add_subplot(projection='3d')
    chart_type = FigureCanvasTkAgg(figure, frame5)
    ax.set_title("Position of the Final Effector")

    xi, yi, zi = pos_ant

    ax.scatter(xi, yi, zi, label='Current Position')
    if pos_sig:
        xd, yd, zd = pos_sig
        ax.scatter(xd, yd, zd, marker="x", c="red", label='Next Position')
    ax.legend()
    chart_type.get_tk_widget().pack(expand=True)
    frame5.grid(column=1, row=1, columnspan=2, sticky="WENS", padx=5)


frame1 = tkinter.LabelFrame(text="BASIC COMMANDS", bg=PRIMARY_COLOR, fg=SECONDARY_COLOR)
home_button = tkinter.Button(frame1, text='HOME', bg=SECONDARY_COLOR, highlightbackground=PRIMARY_COLOR)
home_button.pack(expand=True)
run_button = tkinter.Button(frame1, text='RUN', bg=SECONDARY_COLOR, highlightbackground=PRIMARY_COLOR, command=run)
run_button.pack(expand=True)
frame1.grid(column=0, row=0, sticky="WENS", padx=5)

frame2 = tkinter.LabelFrame(text="JOINS", bg=PRIMARY_COLOR, fg=SECONDARY_COLOR)
frame2.columnconfigure([0, 1], weight=1)
frame2.rowconfigure([0, 1, 2, 3], weight=1)

q1_label = tkinter.Label(frame2, text='q1:', bg=PRIMARY_COLOR, fg=SECONDARY_COLOR)
q1_label.grid(column=0, row=0)
q1_entry = tkinter.Entry(frame2, width=10, highlightbackground=PRIMARY_COLOR, textvariable=tkinter.StringVar(value='0'))
q1_entry.grid(column=1, row=0)
q1_entry.focus()

q2_label = tkinter.Label(frame2, text='q2:', bg=PRIMARY_COLOR, fg=SECONDARY_COLOR)
q2_label.grid(column=0, row=1)
q2_entry = tkinter.Entry(frame2, width=10, highlightbackground=PRIMARY_COLOR, textvariable=tkinter.StringVar(value='0'))
q2_entry.grid(column=1, row=1)

q3_label = tkinter.Label(frame2, text='q3:', bg=PRIMARY_COLOR, fg=SECONDARY_COLOR)
q3_label.grid(column=0, row=2)
q3_entry = tkinter.Entry(frame2, width=10, highlightbackground=PRIMARY_COLOR, textvariable=tkinter.StringVar(value='0'))
q3_entry.grid(column=1, row=2)

calculate_button_joins = tkinter.Button(frame2, text='CALCULATE', bg=SECONDARY_COLOR, highlightbackground=PRIMARY_COLOR,
                                        command=calculate_joins)
calculate_button_joins.grid(column=0, row=3, columnspan=3)

frame2.grid(column=1, row=0, sticky="WENS", padx=5)

frame3 = tkinter.LabelFrame(text="POSITIONS", bg=PRIMARY_COLOR, fg=SECONDARY_COLOR)
frame3.columnconfigure([0, 1], weight=1)
frame3.rowconfigure([0, 1, 2, 3], weight=1)

x_label = tkinter.Label(frame3, text='X:', bg=PRIMARY_COLOR, fg=SECONDARY_COLOR)
x_label.grid(column=0, row=0)
x_entry = tkinter.Entry(frame3, width=10, highlightbackground=PRIMARY_COLOR)
x_entry.grid(column=1, row=0)

y_label = tkinter.Label(frame3, text='Y:', bg=PRIMARY_COLOR, fg=SECONDARY_COLOR)
y_label.grid(column=0, row=1)
y_entry = tkinter.Entry(frame3, width=10, highlightbackground=PRIMARY_COLOR)
y_entry.grid(column=1, row=1)

z_label = tkinter.Label(frame3, text='Z:', bg=PRIMARY_COLOR, fg=SECONDARY_COLOR)
z_label.grid(column=0, row=2)
z_entry = tkinter.Entry(frame3, width=10, highlightbackground=PRIMARY_COLOR)
z_entry.grid(column=1, row=2)

calculate_button_positions = tkinter.Button(frame3, text='CALCULATE', bg=SECONDARY_COLOR,
                                            highlightbackground=PRIMARY_COLOR, command=calculate_positions)
calculate_button_positions.grid(column=0, row=3, columnspan=3)

frame3.grid(column=2, row=0, sticky="WENS", padx=5)

frame4 = tkinter.LabelFrame(text="EFFECTOR", bg=PRIMARY_COLOR, fg=SECONDARY_COLOR)
on_button = tkinter.Button(frame4, text='ON', width=5, bg=SECONDARY_COLOR, highlightbackground=PRIMARY_COLOR,
                           command=effector_on)
on_button.pack(expand=True)
off_button = tkinter.Button(frame4, text='OFF', width=5, bg=SECONDARY_COLOR, highlightbackground=PRIMARY_COLOR,
                            command=effector_off)
off_button.pack(expand=True)
off_button['state'] = 'disabled'
frame4.grid(column=3, row=0, sticky="WENS", padx=5)

frame5 = tkinter.LabelFrame(text="PLOT", bg=PRIMARY_COLOR, fg=SECONDARY_COLOR)
figure = plt.Figure(figsize=(3, 3), dpi=100)
ax = figure.add_subplot(projection='3d')
chart_type = FigureCanvasTkAgg(figure, frame5)
ax.set_title("Position of the Final Effector")
chart_type.get_tk_widget().pack(expand=True)

frame5.grid(column=1, row=1, columnspan=2, sticky="WENS", padx=5)

frame6 = tkinter.LabelFrame(text="CONFIGURATION", height=100, width=100, bg=PRIMARY_COLOR, fg=SECONDARY_COLOR)
frame7 = tkinter.LabelFrame(frame6, text="PORTS", height=100, width=100, bg=PRIMARY_COLOR, fg=SECONDARY_COLOR, padx=5,
                            pady=5)
ports_list = tkinter.Listbox(frame7, width=20, height=5)
ports_list.pack()

viable_ports = get_ports()
ports_list.insert(0, *viable_ports)

select_port_btn = tkinter.Button(frame7, text='SET PORT', width=10, bg=SECONDARY_COLOR,
                                 highlightbackground=PRIMARY_COLOR, command=set_port)
select_port_btn.pack()
search_port_btn = tkinter.Button(frame7, text='SEARCH', width=10, bg=SECONDARY_COLOR, highlightbackground=PRIMARY_COLOR,
                                 command=search_port)
search_port_btn.pack()
frame7.pack()
frame6.grid(column=0, row=2, sticky="WENS", columnspan=4, padx=5)

window.mainloop()
