import numpy as np

l1 = 11.5
l2 = 3.5
l3 = 9.5
l4 = 7.5
def forward_kinematics(q1,q2,q3):

    q1 = q1*np.pi/180
    q2 = q2*np.pi/180
    q3 = q3*np.pi/180

    # CINEMATICA DIRECTA

    y = -l2 * np.sin(q1) + l3 * np.cos(q1) * np.cos(q2) + l4 * np.cos(q1) * np.cos(q2 + q3)
    x = -l2 * np.cos(q1) - l3 * np.sin(q1) * np.cos(q2) - l4 * np.sin(q1) * np.cos(q2 + q3)
    z = l1 + l3 * np.sin(q2) + l4 * np.sin(q2 + q3)
    return [round(x,3),round(y,3),round(z,3)]

def inverse_kinematics(x,y,z):

    # CINEMATICA INVERSA
    q1 = np.arctan2(-x,y) - np.arcsin(l2 / np.sqrt(x**2 + y**2))
    alfa = np.arctan2(-x,y)
    beta = np.arcsin(l2 / np.sqrt(x**2 + y**2))
    rr = (np.sqrt(x**2 + y**2)) * np.cos(beta)
    q3 = 180 - (np.arccos((l4**2 + l3**2 - (np.sqrt(rr**2+(z-l1)**2))**2) / (2*l4*l3)))*180/np.pi
    phi = np.arctan2((z-l1) , rr)
    angulo = np.arccos((-l4 ** 2 + l3 ** 2 + (np.sqrt(rr ** 2 + (z - l1) ** 2)) ** 2) / (2 * l3 * (np.sqrt(rr ** 2 + (z - l1) ** 2))))
    q2 = phi*180/np.pi - angulo*180/np.pi

    return [round(q1,3),round(q2,3),round(q3,3)]


[x,y,z] = forward_kinematics(0,10,10)
print(x,y,z)
[q1,q2,q3] = inverse_kinematics(x,y,z)
print(q1*180/np.pi,q2,q3)

