from kinematics import forward_kinematics, inverse_kinematics

q1 = float(input('q1: '))
q2 = float(input('q2: '))
q3 = float(input('q3: '))

[x,y,z] = forward_kinematics(q1,q2,q3)
print(x,y,z)
[q1,q2,q3] = inverse_kinematics(x,y,z)
print(q1,q2,q3)
